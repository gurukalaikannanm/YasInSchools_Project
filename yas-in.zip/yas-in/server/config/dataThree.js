export default [
    {
        id: 1,
        questionthree: "The mini 4x4 car designs include mechanical engineering, electronics and….",
        options: [
            'Coding & ultrasonics',
            'Coding & app design',
            'Traction Control',
        ]
    },
    {
        id: 2,
        questionthree: "The program is open to students from?",
        options: [
            'Schools & Universities',
            'Technical Colleges',
            'All of Above',
        ]
    },
    {
        id: 3,
        questionthree: "Which of below is a special 4x4 in Schools car feature",
        options: [
            'Fog Lights',
            'Auto Tow Hookt',
            'Launch Control',
        ]
    },
    {
        id: 4,
        questionthree: "What do teams need to focus on to win the terrain challenge?",
        options: [
            'Speed & agility',
            'Precise maneuvering',
            'Battery levels'
        ]
    }
   
];

export const answersthree = [1, 2, 1, 1];
