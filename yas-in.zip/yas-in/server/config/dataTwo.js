export default [
    {
        id: 1,
        questiontwo: "What do teams use the CNC Router technology for?",
        options: [
            'Manufacture the car body',
            'Design the car body',
            'Test their design',
        ]
    },
    {
        id: 2,
        questiontwo: "What does C.A.D stand for?",
        options: [
            'Car Aero Design',
            'Computer App. Design',
            'Computer Aided Design',
        ]
    },
    {
        id: 3,
        questiontwo: "F1 in Schools includes what types of engineering skills?",
        options: [
            'CAD / CAM',
            'Aerodynamics',
            'All of Above',
        ]
    },
    {
        id: 4,
        questiontwo: "What type of learning do students focus on to make their cars faster?",
        options: [
            'Race car design',
            'STEM',
            'Math & science'
        ]
    },
    
];

export const answerstwo = [0, 2, 2, 1];
