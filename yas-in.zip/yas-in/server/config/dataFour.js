export default [
    {
        id: 1,
        questionfour: "How long is the race distance?",
        options: [
            'About 1 second',
            '25 meters',
            '20 meters',
        ]
    },
    {
        id: 2,
        questionfour: "What helps a team have the  fastest race time?",
        options: [
            'Reaction Time',
            'Car Design',
            'All of Above',
        ]
    },
    {
        id: 3,
        questionfour: "How accurately are race times measured to?",
        options: [
            '100th seconds',
            'Milliseconds',
            'Microseconds',
        ]
    },
    {
        id: 4,
        questionfour: "What science learning does the racing include?",
        options: [
            'Motion & Logic',
            'Reaction times',
            'Physics & Statistics'
        ]
    }
];

export const answersfour = [2, 2, 1, 2];
