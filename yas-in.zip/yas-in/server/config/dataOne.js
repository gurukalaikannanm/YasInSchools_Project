export default [
    {
        id: 1,
        question : "What age group of students participate?",
        options : [
            '3 – 6 years old',
            '6 – 13 years old',
            '13 – 24 years old',
        ],

    },
    {
        id: 2,
        question : "What is a Formula Ethara Car made from?",
        options : [
            'Foam model block',
            'Plastic',
            'Paper card',
        ],

    },
    {
        id: 3,
        question : "How many students are in a Formula Ethara team?",
        options : [
            '2 only',
            '3 or 4',
            'Up to 10',
        ],

    },
    {
        id: 4,
        question : "What project elements do teams need to create?",
        options : [
            'Car & Presentation',
            'Car & TV commercial',
            'Website & report'
        ],
     

    },
    
];

export const answers = [0, 2, 1, 0];